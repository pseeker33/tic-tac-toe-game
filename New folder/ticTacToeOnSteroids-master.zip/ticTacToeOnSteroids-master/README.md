# Pending things
1.   create finish game modal
     1.   Add a replay button -> takes to /history/gameID
     2.   give the winner a crown
2.   create sound effect system ( a part of creating the navbar ) 
3.   complete watch game system