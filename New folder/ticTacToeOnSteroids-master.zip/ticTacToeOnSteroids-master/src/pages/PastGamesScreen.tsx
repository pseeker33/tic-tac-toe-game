//this game is used to view past games in a drawn out list same layout as MainPlayScreen  : /histor
export default <div></div>